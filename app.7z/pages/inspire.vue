<template>
  <v-card>
    <v-card-title class="headline">
      {{ page.title }}
    </v-card-title>
    <v-card-subtitle>
      <b>Created:</b> {{ page.createdAt }}
      <br>
      <b>Updated:</b> {{ page.updatedAt }}
    </v-card-subtitle>
    <v-card-text>
      <nuxt-content :document="page" />
    </v-card-text>
  </v-card>
</template>

<script>
export default {
  async asyncData ({ $content }) {
    const page = await $content('hello').fetch()

    return {
      page
    }
  }
}
</script>
